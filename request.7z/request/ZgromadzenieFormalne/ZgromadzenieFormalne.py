import time
import request
import openpyxl
import os
from ZgromadzenieFormalne import Pisz3

def pisz(now):
    print("pisze do CIEBIE doit xdd")
    print(now)

    Email1 = now.get('input 1')
    NazwaFunduszu = now.get('input 2')
    MiejsceZgromadzenia = now.get('input 3')
    Godzina = now.get('input 4')
    PodstawaZwolania = now.get('input 5')
    RodzajCertyfikatów = now.get('input 6')
    TerminPodstawa = now.get('input 7')
    NumerUchwalyZarzadu = now.get('input 8')
    EmailFundusz = now.get('input 9')
    KomentarzRB = now.get('input 10')
    Zawiadamjajacy = now.get('input 11')
    Stanowisko = now.get('input 12')

    Uchwała1 = now.get('input 13')
    Uchwała2 = now.get('input 14')
    Uchwała3 = now.get('input 15')
    Uchwała4 = now.get('input 16')
    Uchwała5 = now.get('input 17')
    Uchwała6 = now.get('input 18')
    Uchwała7 = now.get('input 19')
    Uchwała8 = now.get('input 20')


    folder_path = "ZgromadzenieFormalne"
    file_name = "DaneEdit.xlsm"
    file_path = os.path.join(folder_path, file_name)

    try:
        # Open the existing Excel file
        workbook = openpyxl.load_workbook(file_path, data_only=False, keep_vba=True)
        sheet_name = "Dane"
        worksheet = workbook[sheet_name]

        # Write data to Excel cells
        worksheet['B2'] = NazwaFunduszu
        worksheet['B3'] = MiejsceZgromadzenia
        worksheet['B4'] = Godzina
        worksheet['B5'] = PodstawaZwolania
        worksheet['B6'] = RodzajCertyfikatów
        worksheet['B7'] = TerminPodstawa
        worksheet['B8'] = NumerUchwalyZarzadu
        worksheet['B10'] = EmailFundusz
        worksheet['B11'] = KomentarzRB
        worksheet['B12'] = Zawiadamjajacy
        worksheet['B13'] = Stanowisko

        worksheet['D2'] = Uchwała1
        worksheet['D3'] = Uchwała2
        worksheet['D4'] = Uchwała3
        worksheet['D5'] = Uchwała4
        worksheet['D6'] = Uchwała5
        worksheet['D7'] = Uchwała6
        worksheet['D8'] = Uchwała7
        worksheet['D9'] = Uchwała8

        
        
        

        
        # ... (continue with other cells as needed)

        # Save the modified Excel file
        workbook.save(file_path)
        print(f"Excel file '{file_name}' updated and saved.")
        Pisz3.pisz3()
        print("Pisanie zakończone")
    except Exception as e:
        print(f"An error occurred: {e}")





if __name__ == '__main__':
    pisz()


