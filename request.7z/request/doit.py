import time
import request

def piszFormalneZI(input_dict):
    print("pisze do CIEBIE doit xdd")
    print("print rób kurwa")
    print(input_dict.get('input 1'))
    







if __name__ == '__main__':
    piszFormalneZI()


