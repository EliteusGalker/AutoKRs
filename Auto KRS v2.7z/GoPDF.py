import pdfplumber
import re
import os
import win32com.client
import GoWORD

# Open the PDF file
with pdfplumber.open('example.pdf') as pdf:
    extracted_text = ""
    for page in pdf.pages:
        extracted_text += page.extract_text()
print(extracted_text)


text = extracted_text




#Firma

pattern = r'3\.Firma, pod którą spółka działa (.+)'
match = re.search(pattern, text)

if match:
    FIRMA = match.group(1)
    print("Firma:", FIRMA)
else:
    print("FIRMA not found")


#Oznaczenie sądu

pattern = r'Oznaczenie sądu (.+)'
match = re.search(pattern, text)

if match:
    SĄD = match.group(1)
    print("SĄD:", SĄD)
else:
    print("SĄD not found")



#Adres

pattern = r'2\.Adres (.+)'
match = re.search(pattern, text)

if match:
    ADRES = match.group(1)
    print("Adres:", ADRES)
    print(ADRES.split(', '))
    ulica = ADRES.split(', ')[0]
    budynek = ADRES.split(', ')[1]
    lokal = ADRES.split(', ')[2]
    miejscowosc = ADRES.split(', ')[3]
    kodPocztowy = ADRES.split(', ')[4]
    poczta = ADRES.split(', ')[5]
    print(f'ulca: {ulica}')
    print(f'budynek: {budynek}')
    print(f'lokal: {lokal}')
    print(f'miejscowosc: {miejscowosc}')
    print(f'kod pocztowy: {kodPocztowy}')
    print(f'poczta: {poczta}')
    
    
else:
    print("Adres not found")



#Kapitał Zakładowy

pattern = r'1\.Wysokość kapitału zakładowego (.+)'
match = re.search(pattern, text)

if match:
    KAPITAŁ = match.group(1)
    print("Kapitał Zakładowy:", KAPITAŁ)
else:
    print("Kapitał Zakładowy not found")






#KRS
# Define a regular expression pattern to match "Numer KRS:" followed by digits
pattern = r'Numer KRS:\s*(\d+)'
# Search for the pattern in the text
match = re.search(pattern, text)

if match:
    KRS = match.group(1)
    print("KRS:", KRS)
else:
    print("KRS  not found")


#REGON
pattern = r'REGON:\s*(\d+)'
match = re.search(pattern, text)

if match:
    REGON = match.group(1)
    print("REGON:", REGON)
else:
    print("REGON not found")


#REGON
pattern = r'NIP:\s*(\d+)'
match = re.search(pattern, text)

if match:
    NIP = match.group(1)
    print("NIP:", NIP)
else:
    print("NIP not found")


# ZARZĄD 
outer_pattern = r'Dział 2(.*?)Rubryka 2'

# Define the inner pattern
inner_pattern = r'(1\..+?|2\..+?|3\..+?|4\..+?|5\..+?)\n'

# Use re.search to find the outer pattern in the text
outer_match = re.search(outer_pattern, text, re.DOTALL)

if outer_match:
    # Extract the text matched by the outer pattern
    outer_text = outer_match.group(1)
    
    # Search for the inner pattern within the extracted text
    inner_matches = re.findall(inner_pattern, outer_text, re.DOTALL)


    
    # Print the matched text segments from the inner pattern
    for match in inner_matches:
        print(match.strip())  # Strip whitespace for cleaner output
else:
    print("Outer pattern not found")



skipped_inner_matches = inner_matches[2:]

custom_dictionary = {}

# Define the number of subsequent elements to include in each element of the dictionary
subsequent_elements_count = 5

# Loop through the list and group elements into the custom dictionary
for i in range(0, len(skipped_inner_matches), subsequent_elements_count):
    key = f"Element {i // subsequent_elements_count + 1}"
    value = skipped_inner_matches[i:i + subsequent_elements_count]
    custom_dictionary[key] = value

# Print the custom dictionary
for key, value in custom_dictionary.items():
    print(key)
    for element in value:
        print(element)
    print()

substrings_to_remove = [
    "5.Funkcja w organie reprezentującym",
    "3.Numer PESEL/REGON lub data",
    "2.Imiona",
    "1.Nazwisko / Nazwa lub Firma",
    "­",
    ", ------",
    "4.Numer KRS"
]

# Iterate through the custom dictionary and remove the specified substrings from all elements
for key, value in custom_dictionary.items():
    updated_value = []  # Create an empty list to store updated elements
    for element in value:
        for substring in substrings_to_remove:
            element = element.replace(substring, '').strip()
        updated_value.append(element)  # Add the updated element to the list
    custom_dictionary[key] = updated_value  # Update the value in the custom dictionary

# Print the updated custom dictionary
for key, value in custom_dictionary.items():
    print(key)
    for element in value:
        print(element)
    print()

zarzad = custom_dictionary

GoWORD.GoWord(zarzad)











