import os
import win32com.client


def GoWord(zarzad):

    custom_dictionary = zarzad

    # Get the current directory where the script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # Specify the name of the existing Word document in the same directory
    document_name = "pozyczka.docx"

    # Construct the full path to the document
    document_path = os.path.join(script_dir, document_name)

    # Create a new instance of Word
    word = win32com.client.Dispatch("Word.Application")

    # Make Word visible (optional)
    word.Visible = True

    # Open the existing document
    doc = word.Documents.Open(document_path)

    # Get the content control for the main document
    content = doc.Content

    
    
    content.ParagraphFormat.SpaceAfter = 0
    content.ParagraphFormat.SpaceBefore = 0
    

    for key, values in custom_dictionary.items():
        if len(values) >= 5:  # Check if there are at least 5 values
            second_value = values[1]
            first_value = values[0]
            fifth_value = values[4]
            
            
                      
            content.InsertAfter("---\n")
            content.InsertAfter(f"{second_value} ")

            
            
            content.InsertAfter(f"{first_value}\n")
            content.InsertAfter(f"{fifth_value}\n\n")
        else:
            print(" NIE len(values) >= 5")


    # Save changes (optional)
    doc.Save()

    # Close the document (optional)
    doc.Close()

    # Close Word (optional)
    word.Quit()

if __name__ == '__main__':
    GoWord()
